semantics
================================

.. automodule:: grave_settings.semantics
   :members:
   :undoc-members:
   :show-inheritance:
