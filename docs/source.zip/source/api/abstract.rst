abstract
===============================

.. automodule:: grave_settings.abstract
   :members:
   :undoc-members:
   :show-inheritance:
