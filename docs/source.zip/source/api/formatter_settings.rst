formatter\_settings
==========================================

.. automodule:: grave_settings.formatter_settings
   :members:
   :undoc-members:
   :show-inheritance:
