default\_route
=====================================

.. automodule:: grave_settings.default_route
   :members:
   :undoc-members:
   :show-inheritance:
